package com.example.demo.model;
public class Student{
    public String id;
    public String name;
    public int age;
    public String adhar;
    public String university;
    public Student(String id,String name,int age,String adhar,String university){
        this.id=id;
        this.name=name;
        this.age=age;
        this.adhar=adhar;
        this.university=university;
    }





}
